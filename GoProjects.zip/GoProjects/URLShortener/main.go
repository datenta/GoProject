package main

import (
	"log"
	"net/http"
	"os"
)

func main() {
	storageType := "bolt"
	if len(os.Args) > 1 {
		storageType = os.Args[1]
	}

	storage, err := NewStorage(storageType)
	if err != nil {
		log.Fatalf("Failed to initialize storage: %v", err)
	}
	defer storage.Close()

	http.HandleFunc("/shorten", shortenHandler(storage))
	http.HandleFunc("/", redirectHandler(storage))

	port := ":8080"
	log.Printf("URL Shortener running on http://localhost%s", port)
	log.Fatal(http.ListenAndServe(port, nil))
}
