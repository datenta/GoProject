package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type ShortenRequest struct {
	URL string `json:"url"`
}

type ShortenResponse struct {
	ShortURL string `json:"short_url"`
}

func shortenHandler(storage Storage) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		var req ShortenRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}

		shortKey, err := storage.Shorten(req.URL)
		if err != nil {
			if err == ErrInvalidURL {
				http.Error(w, "Invalid URL", http.StatusBadRequest)
				return
			}
			http.Error(w, "Failed to shorten URL", http.StatusInternalServerError)
			return
		}

		shortURL := fmt.Sprintf("http://%s/%s", r.Host, shortKey)
		response := ShortenResponse{ShortURL: shortURL}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(response)
	}
}

func redirectHandler(storage Storage) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		shortKey := r.URL.Path[1:]
		if shortKey == "" {
			http.Error(w, "Not found", http.StatusNotFound)
			return
		}

		originalURL, err := storage.Expand(shortKey)
		if err != nil {
			if err == ErrURLNotFound {
				http.Error(w, "URL not found", http.StatusNotFound)
				return
			}
			http.Error(w, "Internal server error", http.StatusInternalServerError)
			return
		}

		http.Redirect(w, r, originalURL, http.StatusFound)
	}
}
