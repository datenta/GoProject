package main

import (
	"errors"
	"fmt"
	"math/rand"
	"net/url"
	"time"

	bolt "go.etcd.io/bbolt"
)

var (
	ErrURLNotFound = errors.New("URL not found")
	ErrInvalidURL  = errors.New("invalid URL")
)

type Storage interface {
	Shorten(originalURL string) (string, error)
	Expand(shortKey string) (string, error)
	Close() error
}

type MemoryStorage struct {
	urls map[string]string
}

func NewMemoryStorage() *MemoryStorage {
	return &MemoryStorage{
		urls: make(map[string]string),
	}
}

func (m *MemoryStorage) Shorten(originalURL string) (string, error) {
	if !isValidURL(originalURL) {
		return "", ErrInvalidURL
	}

	shortKey := generateShortKey()
	m.urls[shortKey] = originalURL
	return shortKey, nil
}

func (m *MemoryStorage) Expand(shortKey string) (string, error) {
	originalURL, exists := m.urls[shortKey]
	if !exists {
		return "", ErrURLNotFound
	}
	return originalURL, nil
}

func (m *MemoryStorage) Close() error {
	return nil
}

type BoltStorage struct {
	db *bolt.DB
}

func NewBoltStorage() (*BoltStorage, error) {
	db, err := bolt.Open("urlshortener.db", 0600, nil)
	if err != nil {
		return nil, err
	}

	err = db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucketIfNotExists([]byte("urls"))
		return err
	})

	if err != nil {
		return nil, err
	}

	return &BoltStorage{db: db}, nil
}

func (b *BoltStorage) Shorten(originalURL string) (string, error) {
	if !isValidURL(originalURL) {
		return "", ErrInvalidURL
	}

	shortKey := generateShortKey()

	err := b.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("urls"))
		return bucket.Put([]byte(shortKey), []byte(originalURL))
	})

	if err != nil {
		return "", err
	}

	return shortKey, nil
}

func (b *BoltStorage) Expand(shortKey string) (string, error) {
	var originalURL string

	err := b.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("urls"))
		urlBytes := bucket.Get([]byte(shortKey))
		if urlBytes == nil {
			return ErrURLNotFound
		}
		originalURL = string(urlBytes)
		return nil
	})

	if err != nil {
		return "", err
	}

	return originalURL, nil
}

func (b *BoltStorage) Close() error {
	return b.db.Close()
}

func NewStorage(storageType string) (Storage, error) {
	switch storageType {
	case "memory":
		return NewMemoryStorage(), nil
	case "bolt":
		return NewBoltStorage()
	default:
		return nil, fmt.Errorf("unknown storage type: %s", storageType)
	}
}

func generateShortKey() string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	const keyLength = 6

	rand.Seed(time.Now().UnixNano())
	shortKey := make([]byte, keyLength)
	for i := range shortKey {
		shortKey[i] = charset[rand.Intn(len(charset))]
	}
	return string(shortKey)
}

func isValidURL(rawURL string) bool {
	u, err := url.Parse(rawURL)
	if err != nil {
		return false
	}
	if u.Scheme == "" || u.Host == "" {
		return false
	}
	return true
}
