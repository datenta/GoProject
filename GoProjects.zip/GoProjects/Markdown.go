package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: md2html <input.md> [output.html]")
		return
	}

	inputFile := os.Args[1]
	outputFile := "output.html"
	if len(os.Args) > 2 {
		outputFile = os.Args[2]
	}

	content, err := readMarkdownFile(inputFile)
	if err != nil {
		fmt.Printf("Error reading file: %v\n", err)
		return
	}

	html := convertMarkdownToHTML(content)

	err = writeHTMLFile(outputFile, html)
	if err != nil {
		fmt.Printf("Error writing HTML file: %v\n", err)
		return
	}

	fmt.Printf("Successfully converted %s to %s\n", inputFile, outputFile)
}

func readMarkdownFile(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var lines []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}
	return lines, scanner.Err()
}

func convertMarkdownToHTML(lines []string) string {
	var html strings.Builder
	html.WriteString("<!DOCTYPE html>\n<html>\n<head>\n<title>Markdown Conversion</title>\n</head>\n<body>\n")

	inList := false
	inCodeBlock := false

	for _, line := range lines {
		if strings.HasPrefix(line, "```") {
			if inCodeBlock {
				html.WriteString("</code></pre>\n")
				inCodeBlock = false
			} else {
				html.WriteString("<pre><code>\n")
				inCodeBlock = true
			}
			continue
		}

		if inCodeBlock {
			html.WriteString(line + "\n")
			continue
		}

		if strings.HasPrefix(line, "# ") {
			html.WriteString("<h1>" + line[2:] + "</h1>\n")
			continue
		} else if strings.HasPrefix(line, "## ") {
			html.WriteString("<h2>" + line[3:] + "</h2>\n")
			continue
		} else if strings.HasPrefix(line, "### ") {
			html.WriteString("<h3>" + line[4:] + "</h3>\n")
			continue
		}

		if strings.HasPrefix(line, "- ") || strings.HasPrefix(line, "* ") {
			if !inList {
				html.WriteString("<ul>\n")
				inList = true
			}
			html.WriteString("<li>" + line[2:] + "</li>\n")
			continue
		} else if inList {
			html.WriteString("</ul>\n")
			inList = false
		}

		line = strings.ReplaceAll(line, "**", "<strong>")
		line = strings.ReplaceAll(line, "__", "<strong>")
		line = strings.ReplaceAll(line, "*", "<em>")
		line = strings.ReplaceAll(line, "_", "<em>")

		line = replaceLinks(line)

		if line != "" {
			html.WriteString("<p>" + line + "</p>\n")
		}
	}

	if inList {
		html.WriteString("</ul>\n")
	}
	if inCodeBlock {
		html.WriteString("</code></pre>\n")
	}

	html.WriteString("</body>\n</html>")
	return html.String()
}

func replaceLinks(line string) string {
	start := strings.Index(line, "[")
	end := strings.Index(line, ")")
	if start != -1 && end != -1 && end > start {
		linkText := line[start+1 : strings.Index(line, "]")]
		urlStart := strings.Index(line, "(") + 1
		url := line[urlStart:end]
		return line[:start] + "<a href=\"" + url + "\">" + linkText + "</a>" + line[end+1:]
	}
	return line
}

func writeHTMLFile(filename string, content string) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = file.WriteString(content)
	return err
}
