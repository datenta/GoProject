package main

import (
	"bufio"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strings"

	"golang.org/x/net/html"
)

type Result struct {
	URL   string
	Title string
	Error error
}

func main() {
	fmt.Println("Web Scraper - Extract Page Titles")
	fmt.Println("Enter URLs (one per line), then press Ctrl+Z (Windows) or Ctrl+D (Unix) to process:")

	scanner := bufio.NewScanner(os.Stdin)
	var urls []string

	for scanner.Scan() {
		rawURL := strings.TrimSpace(scanner.Text())
		if rawURL != "" {
			urls = append(urls, rawURL)
		}
	}

	if err := scanner.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "Error reading input: %v\n", err)
		return
	}

	if len(urls) == 0 {
		fmt.Println("No URLs provided")
		return
	}

	results := make(chan Result)
	for _, u := range urls {
		go func(url string) {
			title, err := scrapeTitle(url)
			results <- Result{URL: url, Title: title, Error: err}
		}(u)
	}

	fmt.Println("\nResults:")
	fmt.Println("----------------------------------------")
	for i := 0; i < len(urls); i++ {
		result := <-results
		if result.Error != nil {
			fmt.Printf("URL: %s\nError: %v\n", result.URL, result.Error)
		} else {
			fmt.Printf("URL: %s\nTitle: %s\n", result.URL, result.Title)
		}
		fmt.Println("----------------------------------------")
	}
}

func scrapeTitle(rawURL string) (string, error) {
	parsedURL, err := url.ParseRequestURI(rawURL)
	if err != nil {
		return "", fmt.Errorf("invalid URL: %w", err)
	}

	resp, err := http.Get(parsedURL.String())
	if err != nil {
		return "", fmt.Errorf("HTTP request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("HTTP status %d", resp.StatusCode)
	}

	title, err := extractTitle(resp.Body)
	if err != nil {
		return "", fmt.Errorf("parsing HTML failed: %w", err)
	}

	return title, nil
}

func extractTitle(r io.Reader) (string, error) {
	doc, err := html.Parse(r)
	if err != nil {
		return "", err
	}

	var title string
	var f func(*html.Node)
	f = func(n *html.Node) {
		if n.Type == html.ElementNode && n.Data == "title" {
			if n.FirstChild != nil {
				title = n.FirstChild.Data
			}
			return
		}
		for c := n.FirstChild; c != nil; c = c.NextSibling {
			f(c)
		}
	}
	f(doc)

	if title == "" {
		return "", fmt.Errorf("no title found")
	}

	return strings.TrimSpace(title), nil
}
