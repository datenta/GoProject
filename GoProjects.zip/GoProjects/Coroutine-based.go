package main

import (
	"fmt"
	"math"
	"os"
	"strconv"
	"sync"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: prime <number>")
		return
	}

	num, err := strconv.Atoi(os.Args[1])
	if err != nil {
		fmt.Println("Please provide a valid integer")
		return
	}

	if num < 2 {
		fmt.Printf("%d is not a prime number\n", num)
		return
	}

	isPrime := checkPrime(num, 4)
	if isPrime {
		fmt.Printf("%d is a prime number\n", num)
	} else {
		fmt.Printf("%d is not a prime number\n", num)
	}
}

func checkPrime(num, numWorkers int) bool {
	if num <= 1 {
		return false
	}
	if num <= 3 {
		return true
	}
	if num%2 == 0 || num%3 == 0 {
		return false
	}

	maxDivisor := int(math.Sqrt(float64(num))) + 1
	workRange := maxDivisor / numWorkers

	if workRange < 10 {
		workRange = 10
		numWorkers = maxDivisor / workRange
		if numWorkers < 1 {
			numWorkers = 1
		}
	}

	results := make(chan bool, numWorkers)
	var wg sync.WaitGroup

	for i := 0; i < numWorkers; i++ {
		wg.Add(1)
		start := i*workRange + 1
		end := (i + 1) * workRange

		if i == numWorkers-1 {
			end = maxDivisor
		}

		if start < 5 {
			start = 5
		} else if start%2 == 0 {
			start++
		}

		go func(start, end int) {
			defer wg.Done()
			for d := start; d <= end; d += 2 {
				select {
				case <-results:
					return
				default:
					if num%d == 0 {
						results <- false
						return
					}
				}
			}
		}(start, end)
	}

	go func() {
		wg.Wait()
		results <- true
	}()

	return <-results
}
