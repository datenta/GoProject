package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type Todo struct {
	Description string `json:"description"`
	Done        bool   `json:"done"`
}

var todos []Todo

const dataFile = "todos.json"

func main() {
	loadTodos()
	displayHelp()

	reader := bufio.NewReader(os.Stdin)

	for {
		fmt.Print("> ")
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)
		parts := strings.SplitN(input, " ", 2)

		command := parts[0]
		arg := ""
		if len(parts) > 1 {
			arg = parts[1]
		}

		switch command {
		case "add":
			if arg == "" {
				fmt.Println("Please provide a task description")
				continue
			}
			addTodo(arg)
		case "list":
			listTodos()
		case "done":
			if arg == "" {
				fmt.Println("Please provide a task number")
				continue
			}
			markDone(arg)
		case "help":
			displayHelp()
		case "exit":
			saveTodos()
			fmt.Println("Goodbye!")
			return
		default:
			fmt.Println("Unknown command. Type 'help' for available commands.")
		}
	}
}

func loadTodos() {
	file, err := os.ReadFile(dataFile)
	if err != nil {
		todos = []Todo{}
		return
	}

	err = json.Unmarshal(file, &todos)
	if err != nil {
		fmt.Printf("Error reading todos: %v\n", err)
		os.Exit(1)
	}
}

func saveTodos() {
	data, err := json.MarshalIndent(todos, "", "  ")
	if err != nil {
		fmt.Printf("Error saving todos: %v\n", err)
		return
	}

	err = os.WriteFile(dataFile, data, 0644)
	if err != nil {
		fmt.Printf("Error writing file: %v\n", err)
	}
}

func addTodo(description string) {
	todos = append(todos, Todo{Description: description, Done: false})
	saveTodos()
	fmt.Printf("Added: %s\n", description)
}

func listTodos() {
	if len(todos) == 0 {
		fmt.Println("No tasks in the list")
		return
	}

	for i, todo := range todos {
		status := " "
		if todo.Done {
			status = "✓"
		}
		fmt.Printf("%d. [%s] %s\n", i+1, status, todo.Description)
	}
}

func markDone(arg string) {
	taskNum, err := strconv.Atoi(arg)
	if err != nil {
		fmt.Println("Please provide a valid task number")
		return
	}

	if taskNum < 1 || taskNum > len(todos) {
		fmt.Println("Invalid task number")
		return
	}

	todos[taskNum-1].Done = true
	saveTodos()
	fmt.Printf("Marked task %d as done\n", taskNum)
}

func displayHelp() {
	fmt.Println("Todo List Application")
	fmt.Println("Commands:")
	fmt.Println("  add <description> - Add a new task")
	fmt.Println("  list              - List all tasks")
	fmt.Println("  done <number>     - Mark task as done")
	fmt.Println("  help              - Show this help")
	fmt.Println("  exit              - Exit the application")
}
