package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

func main() {
	reader := bufio.NewReader(os.Stdin)

	fmt.Println("CLI Calculator")
	fmt.Println("---------------")
	fmt.Println("Available operations:")
	fmt.Println("+ : Addition")
	fmt.Println("- : Subtraction")
	fmt.Println("* : Multiplication")
	fmt.Println("/ : Division")
	fmt.Println("^ : Exponentiation")
	fmt.Println("sqrt : Square Root (enter as operation, first number is used)")
	fmt.Println("----------------")

	for {
		fmt.Print("Enter first number (or 'q' to quit): ")
		num1Input, _ := reader.ReadString('\n')
		num1Input = strings.TrimSpace(num1Input)

		if num1Input == "q" {
			break
		}

		num1, err := strconv.ParseFloat(num1Input, 64)
		if err != nil {
			fmt.Println("Invalid number. Please try again.")
			continue
		}

		fmt.Print("Enter operation (+, -, *, /, ^, sqrt): ")
		operation, _ := reader.ReadString('\n')
		operation = strings.TrimSpace(operation)

		if operation == "sqrt" {
			if num1 < 0 {
				fmt.Println("Cannot calculate square root of a negative number")
			} else {
				result := math.Sqrt(num1)
				fmt.Printf("√%.2f = %.2f\n", num1, result)
			}
			continue
		}

		fmt.Print("Enter second number: ")
		num2Input, _ := reader.ReadString('\n')
		num2Input = strings.TrimSpace(num2Input)

		num2, err := strconv.ParseFloat(num2Input, 64)
		if err != nil {
			fmt.Println("Invalid number. Please try again.")
			continue
		}

		var result float64
		switch operation {
		case "+":
			result = num1 + num2
			fmt.Printf("%.2f + %.2f = %.2f\n", num1, num2, result)
		case "-":
			result = num1 - num2
			fmt.Printf("%.2f - %.2f = %.2f\n", num1, num2, result)
		case "*":
			result = num1 * num2
			fmt.Printf("%.2f * %.2f = %.2f\n", num1, num2, result)
		case "/":
			if num2 == 0 {
				fmt.Println("Error: Division by zero is not allowed")
			} else {
				result = num1 / num2
				fmt.Printf("%.2f / %.2f = %.2f\n", num1, num2, result)
			}
		case "^":
			result = math.Pow(num1, num2)
			fmt.Printf("%.2f ^ %.2f = %.2f\n", num1, num2, result)
		default:
			fmt.Println("Invalid operation. Please try again.")
		}
	}

	fmt.Println("Calculator exited. Goodbye!")
}
