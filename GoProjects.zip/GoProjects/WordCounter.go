package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strings"
)

type WordCount struct {
	Word  string
	Count int
}

func main() {
	if len(os.Args) != 2 {
		fmt.Println("Usage: wordcounter <sample.txt>")
		return
	}
	filename := os.Args[1]

	file, err := os.Open(filename)
	if err != nil {
		fmt.Printf("Error opening file: %v\n", err)
		return
	}
	defer file.Close()

	wordCounts := make(map[string]int)

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		words := strings.Fields(line)

		for _, word := range words {
			word = strings.ToLower(word)
			word = strings.Trim(word, ".,!?;:\"()[]{}")
			if word != "" {
				wordCounts[word]++
			}
		}
	}

	if err := scanner.Err(); err != nil {
		fmt.Printf("Error reading file: %v\n", err)
		return
	}

	var counts []WordCount
	for word, count := range wordCounts {
		counts = append(counts, WordCount{word, count})
	}

	sort.Slice(counts, func(i, j int) bool {
		return counts[i].Count > counts[j].Count
	})

	fmt.Println("Top 5 most frequent words:")
	fmt.Println("--------------------------")
	maxDisplay := 5
	if len(counts) < maxDisplay {
		maxDisplay = len(counts)
	}
	for i := 0; i < maxDisplay; i++ {
		fmt.Printf("%d. %s: %d occurrences\n", i+1, counts[i].Word, counts[i].Count)
	}
}
