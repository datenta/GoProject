package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"strings"
)

const apiKey = "cur_live_bvXxUZKDVvCdVLYPG4pVM16TOYtjsL5Skmbn3VgE"
const apiUrl = "https://v6.exchangerate-api.com/v6/%s/latest/%s"

type ExchangeRateResponse struct {
	Result          string             `json:"result"`
	ConversionRates map[string]float64 `json:"conversion_rates"`
	ErrorType       string             `json:"error-type"`
}

func main() {
	fmt.Println("Currency Converter CLI")
	fmt.Println("----------------------")

	if len(os.Args) < 4 {
		fmt.Println("Usage: currencyconverter <amount> <from_currency> <to_currency>")
		fmt.Println("Example: currencyconverter 100 USD EUR")
		return
	}

	amount, err := strconv.ParseFloat(os.Args[1], 64)
	if err != nil {
		fmt.Println("Invalid amount. Please enter a valid number.")
		return
	}

	fromCurrency := strings.ToUpper(os.Args[2])
	toCurrency := strings.ToUpper(os.Args[3])

	if len(fromCurrency) != 3 || len(toCurrency) != 3 {
		fmt.Println("Currency codes must be 3 letters (e.g., USD, EUR)")
		return
	}

	rates, err := getExchangeRates(fromCurrency)
	if err != nil {
		fmt.Printf("Error getting exchange rates: %v\n", err)
		return
	}

	rate, exists := rates[toCurrency]
	if !exists {
		fmt.Printf("Currency code %s not found in available rates\n", toCurrency)
		fmt.Println("Available currencies:")
		for currency := range rates {
			fmt.Printf("%s ", currency)
		}
		fmt.Println()
		return
	}

	convertedAmount := amount * rate
	fmt.Printf("%.2f %s = %.2f %s\n", amount, fromCurrency, convertedAmount, toCurrency)
}

func getExchangeRates(baseCurrency string) (map[string]float64, error) {
	url := fmt.Sprintf(apiUrl, apiKey, baseCurrency)
	resp, err := http.Get(url)
	if err != nil {
		return nil, fmt.Errorf("API request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("API returned status: %s", resp.Status)
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	var apiResponse ExchangeRateResponse
	err = json.Unmarshal(body, &apiResponse)
	if err != nil {
		return nil, fmt.Errorf("failed to parse JSON: %w", err)
	}

	if apiResponse.Result != "success" {
		return nil, fmt.Errorf("API error: %s", apiResponse.ErrorType)
	}

	return apiResponse.ConversionRates, nil
}
