package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
)

const apiKey = "fc6c1b78335b3443cc68ee9a42908d40"

type WeatherData struct {
	Name string `json:"name"`
	Main struct {
		Temp float64 `json:"temp"`
	} `json:"main"`
	Weather []struct {
		Description string `json:"description"`
	} `json:"weather"`
}

func main() {
	reader := bufio.NewReader(os.Stdin)
	fmt.Print("Enter city name: ")
	city, _ := reader.ReadString('\n')
	city = strings.TrimSpace(city)

	url := fmt.Sprintf("https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric", city, apiKey)

	resp, err := http.Get(url)
	if err != nil {
		fmt.Println("Network error:", err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		fmt.Printf("Failed to get weather data. HTTP Status: %s\n", resp.Status)
		return
	}

	var data WeatherData
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		fmt.Println("Error parsing response:", err)
		return
	}

	if len(data.Weather) == 0 {
		fmt.Println("No weather data found.")
		return
	}

	fmt.Printf("\nWeather in %s:\n", data.Name)
	fmt.Printf("Temperature: %.1f°C\n", data.Main.Temp)
	fmt.Printf("Description: %s\n", strings.Title(data.Weather[0].Description))
}
